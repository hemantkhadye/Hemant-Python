
#######################################################################
# Getting to know the basics : Practise
#######################################################################

l = ['Hi', 'Hello', 'Greetings', 'Okay', 'How are you?', 'Hello']

# Write a Python program to clone or copy a list. Use the variable newList


# Use newList and remove duplcates from it. To remove dulicates use set() function and sort the list in alphabetical order.


# Find the index of the word 'Hello' and use this index to replace 'Hello' with 'newHello'


# Sort the list once again and check if the word 'newHello' exists in the list.


# Print the elements of the list staring from the last word in the list. Use a step of -1


# Extract the second element from the list l and put it in a variable secondWord


# Convert secondWord to lowercase and count the number of 'e' in the word.







