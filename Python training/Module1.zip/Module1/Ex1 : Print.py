
#######################################################################
# Getting to know the basics : Print
#######################################################################

# String
print('Hello, welcome to Python Basics training!')

# Addition
print(1+5)

# Division
print(9/3)

# Exponentiation
print(4 ** 2)

# Print 2 strings together
print('string1' + 'string2')


#######################################################################
# Excercise
#######################################################################

# Print a string
s = ''

print(s)

# Print your name and age together, separated by ':'
yourName = ''
yourAge = ''

print()

# Quick check : What if I print a string and an number together?
#print('Hi : '+ 5)









